! function (n) {
  var e = n.document,
    t = e.documentElement,
    i = 720,
    d = i / 200,
    o = "orientationchange" in n ? "orientationchange" : "resize",
    a = function () {
      var n = t.clientWidth || 320;
      n > 720 && (n = 720);
      t.style.fontSize = n / d + "px"
    };
  e.addEventListener && (n.addEventListener(o, a, !1), e.addEventListener("DOMContentLoaded", a, !1))


  //  阻止浏览器默认
  var startX, startY;
  document.addEventListener("touchstart", function (e) {
    startX = e.targetTouches[0].pageX;
    startY = e.targetTouches[0].pageY;
  });

  document.addEventListener("touchmove", function (e) {

    var moveX = e.targetTouches[0].pageX;
    var moveY = e.targetTouches[0].pageY;

    if (Math.abs(moveX - startX) > Math.abs(moveY - startY)) {
      e.preventDefault();
    }
  }, {
    passive: false
  });
}(window);
